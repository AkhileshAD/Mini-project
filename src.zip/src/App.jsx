import "./App.css";
import Cards from "./Card-section/Cards";
import Header from "./Header-Part/Header";

function App() {

  return (
   <>
   <Header/>
   {/* <Cards></Cards> */}
   </>
  );
}

export default App;
